# Path: ~/garden/ARC_Agirunner/runner/transform_utils.py
import torch
import numpy as np
import heapq
from detectors import DETECTORS, resize_grid
from collections import defaultdict

# Use GPU if available
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# --------------------------
# Core GPU helpers
# --------------------------

def to_tensor(grid):
    """Convert grid (list/numpy/torch) to GPU tensor of ints."""
    if isinstance(grid, torch.Tensor):
        return grid.to(DEVICE)
    return torch.tensor(grid, device=DEVICE, dtype=torch.int64)

def to_cpu_list(tensor):
    """Convert tensor back to Python list (for JSON/logging)."""
    if isinstance(tensor, torch.Tensor):
        return tensor.detach().cpu().numpy().tolist()
    return np.array(tensor).tolist()

# --------------------------
# Apply chain of detectors
# --------------------------

def apply_chain(grid, chain, target_shape=None):
    """
    Apply a sequence of detectors (rules) to a grid on GPU.
    Returns CPU-safe list if successful, else None.
    """
    arr = to_tensor(grid)
    for rule in chain:
        try:
            arr = to_tensor(rule["fn"](to_cpu_list(arr)))  # detectors expect CPU-safe input
        except Exception:
            return None
    if target_shape:
        arr = to_tensor(resize_grid(to_cpu_list(arr), target_shape))
    return to_cpu_list(arr)

# --------------------------
# Chain generation & scoring
# --------------------------

def generate_composite_rules(train_pairs, max_depth=3):
    """Explore compositions of multiple detectors (rule chaining)."""
    rules = []
    for pair in train_pairs:
        inp, out = pair["input"], pair["output"]
        for det in DETECTORS:
            try:
                r = det(inp, out)
                if r:
                    rules.append(r)
            except Exception:
                continue

    # Start with single rules
    base = [[r] for r in rules]
    chains = list(base)
    # Extend chains up to max_depth
    for _ in range(max_depth - 1):
        new_chains = []
        for chain in chains:
            for r in rules:
                new_chains.append(chain + [r])
        chains.extend(new_chains)

    # Deduplicate
    seen = set()
    unique_chains = []
    for chain in chains:
        names = tuple(r["name"] for r in chain)
        if names not in seen:
            seen.add(names)
            unique_chains.append(chain)
    return unique_chains

def evaluate_chain(chain, train_pairs):
    """Score how well a chain explains training pairs."""
    total_score = 0
    for pair in train_pairs:
        pred = apply_chain(pair["input"], chain, target_shape=np.array(pair["output"]).shape)
        if pred is None:
            total_score -= 0.5
            continue
        out = np.array(pair["output"])
        pred = np.array(pred)
        if pred.shape != out.shape:
            total_score -= 0.5
            continue
        match = np.sum(pred == out) / out.size
        total_score += match
    return total_score / len(train_pairs), chain

def best_composite_rules(train_pairs, max_depth=3, top_k=3):
    """Find best composite chains for training pairs."""
    chains = generate_composite_rules(train_pairs, max_depth=max_depth)
    scored = []
    for chain in chains:
        score, chain = evaluate_chain(chain, train_pairs)
        scored.append((score, chain))
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:top_k]

# --------------------------
# Integration helper
# --------------------------

def composite_solver(task, max_depth=3):
    """Solve a task by searching for composite detector chains."""
    train, test = task["train"], task["test"]
    top_chains = best_composite_rules(train, max_depth=max_depth)
    if not top_chains:
        return []

    preds = []
    for score, chain in top_chains:
        for t in test:
            pred = apply_chain(t["input"], chain, target_shape=np.array(t["output"]).shape)
            preds.append({
                "pred": pred,
                "score": score,
                "rules": [r["name"] for r in chain]
            })
    return preds
    
def beam_search_composites(task, beam_width=5, max_depth=4, top_detectors=15):
    """
    Beam search for optimal rule chains instead of exhaustive search.
    Much faster than generate_composite_rules() for deeper compositions.
    """
    train_pairs = task["train"]
    if not train_pairs:
        return []
    
    print(f"🔍 Beam search on {len(train_pairs)} pairs (depth={max_depth}, beam={beam_width})", flush=True)
    
    # Collect candidate single rules (limit to top detectors for speed)
    candidate_rules = []
    rule_cache = defaultdict(list)  # Cache rules per training pair
    
    for pair in train_pairs:
        inp, out = pair["input"], pair["output"]
        pair_rules = []
        
        for det in DETECTORS[:top_detectors]:  # Limit to fastest detectors
            try:
                r = det(inp, out)
                if r:
                    # Quick validation
                    pred = apply_chain(inp, [r], target_shape=np.array(out).shape)
                    if pred is not None and np.array_equal(np.array(pred), out):
                        pair_rules.append(r)
                        candidate_rules.append(r)
            except Exception:
                continue
        
        rule_cache[id(pair)] = pair_rules
    
    if not candidate_rules:
        return []
    
    # Deduplicate rules by name
    unique_rules = {r["name"]: r for r in candidate_rules}.values()
    print(f"   Found {len(unique_rules)} unique candidate rules", flush=True)
    
    # Initialize beam with single rules
    beam = []
    for rule in unique_rules:
        # Score across all training pairs
        total_score = 0
        valid_count = 0
        for pair in train_pairs:
            pred = apply_chain(pair["input"], [rule], target_shape=np.array(pair["output"]).shape)
            if pred is not None:
                match = np.sum(np.array(pred) == np.array(pair["output"])) / np.array(pair["output"]).size
                total_score += match
                valid_count += 1
        
        if valid_count > 0:
            avg_score = total_score / valid_count
            heapq.heappush(beam, (-avg_score, [rule], 1))  # Negative for max-heap
    
    # Beam search expansion
    best_chains = []
    expansions = 0
    
    while beam and len(best_chains) < beam_width * 2:
        neg_score, chain, depth = heapq.heappop(beam)
        score = -neg_score
        
        if depth >= max_depth or expansions > 100:  # Safety limit
            best_chains.append((score, chain))
            continue
        
        # Expand with compatible rules
        current_names = {r["name"] for r in chain}
        for rule in unique_rules:
            if rule["name"] not in current_names:  # Avoid immediate duplicates
                new_chain = chain + [rule]
                
                # Quick early stopping
                quick_score = 0
                quick_valid = 0
                for i, pair in enumerate(train_pairs[:2]):  # Test on first 2 pairs only
                    pred = apply_chain(pair["input"], new_chain, target_shape=np.array(pair["output"]).shape)
                    if pred is not None:
                        match = np.sum(np.array(pred) == np.array(pair["output"])) / np.array(pair["output"]).size
                        quick_score += match
                        quick_valid += 1
                
                if quick_valid > 0 and quick_score / quick_valid > score * 0.8:
                    # Full evaluation
                    total_score = 0
                    valid_count = 0
                    for pair in train_pairs:
                        pred = apply_chain(pair["input"], new_chain, target_shape=np.array(pair["output"]).shape)
                        if pred is not None:
                            match = np.sum(np.array(pred) == np.array(pair["output"])) / np.array(pair["output"]).size
                            total_score += match
                            valid_count += 1
                    
                    if valid_count > 0:
                        avg_score = total_score / valid_count
                        if avg_score > score * 0.9:  # Only keep promising extensions
                            heapq.heappush(beam, (-avg_score, new_chain, depth + 1))
                            expansions += 1
    
    # Sort and return top chains
    best_chains.sort(key=lambda x: x[0], reverse=True)
    top_chains = best_chains[:beam_width]
    
    print(f"   Beam search complete: {len(top_chains)} chains, expansions={expansions}", flush=True)
    return top_chains
# --------------------------
# SMART COMPOSITE SOLVER (ADD THIS AT THE VERY END)
# --------------------------

def smart_composite_solver(task, use_beam_search=True, beam_width=5, max_depth=3):
    """Simple composite solver - no external dependencies."""
    from detectors import DETECTORS
    import numpy as np
    
    train, test = task["train"], task["test"]
    
    if not train:
        return []
    
    print(f"   🔍 Smart composite: {len(train)} train pairs, depth={max_depth}", flush=True)
    
    # Simple rule chaining (max depth 2 for speed)
    all_chains = []
    
    # Get rules from first training pair
    if len(train) > 0:
        inp, out = train[0]["input"], train[0]["output"]
        candidate_rules = []
        
        # Collect single rules
        for det in DETECTORS[:12]:  # First 12 detectors only
            try:
                r = det(inp, out)
                if r:
                    candidate_rules.append(r)
            except:
                continue
        
        print(f"   Found {len(candidate_rules)} candidate rules", flush=True)
        
        # Single rules
        for rule in candidate_rules:
            all_chains.append([rule])
        
        # Simple pairs (depth 2)
        for i, rule1 in enumerate(candidate_rules):
            for rule2 in candidate_rules[i+1:]:
                try:
                    # Test the chain quickly
                    pred1 = rule1["fn"](inp)
                    if pred1 is not None:
                        pred2 = rule2["fn"](pred1)
                        if pred2 is not None:
                            pred_arr = np.array(pred2) if isinstance(pred2, list) else pred2
                            out_arr = np.array(out)
                            if pred_arr.shape == out_arr.shape and np.sum(pred_arr == out_arr) > out_arr.size * 0.3:
                                all_chains.append([rule1, rule2])
                except:
                    continue
    
    # Generate predictions for test cases
    preds = []
    for chain in all_chains[:beam_width]:  # Limit to beam_width chains
        chain_name = "_".join([r["name"] for r in chain])
        
        chain_preds = []
        for test_case in test:
            try:
                pred = test_case["input"]
                for rule in chain:
                    pred = rule["fn"](pred)
                
                if pred is not None:
                    pred_list = pred.tolist() if hasattr(pred, 'tolist') else pred
                    chain_preds.append({
                        "pred": pred_list,
                        "rules": [r["name"] for r in chain],
                        "chain_length": len(chain)
                    })
            except Exception as e:
                print(f"⚠️ Chain {chain_name} failed: {e}", flush=True)
                continue
        
        # Score the chain
        chain_score = 0.5  # Default score
        if "output" in test_case and chain_preds:
            try:
                out_arr = np.array(test_case["output"])
                pred_arr = np.array(chain_preds[0]["pred"])
                if pred_arr.shape == out_arr.shape:
                    chain_score = np.sum(pred_arr == out_arr) / out_arr.size
            except:
                pass
        
        for pred_info in chain_preds:
            pred_info["score"] = chain_score
            preds.append(pred_info)
    
    # Sort by score
    preds.sort(key=lambda x: x.get("score", 0), reverse=True)
    print(f"   Generated {len(preds)} composite predictions", flush=True)
    return preds[:2]  # Return top 2 predictions
