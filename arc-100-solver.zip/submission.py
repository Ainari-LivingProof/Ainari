#!/usr/bin/env python3
"""
Generate Kaggle ARC Prize 2025 submission
"""

import json
import os

def create_submission():
    # Load log
    log_file = os.path.expanduser("~/kaggle/working/meta_log.json")
    with open(log_file, 'r') as f:
        log = json.load(f)

    # Create submission dictionary
    submission = {}
    for task_id, entry in log.items():
        if task_id.startswith('eval_'):
            base_id = task_id.replace('eval_', '')  # Strip 'eval_' prefix
            preds = entry.get('preds', [{}])[0]
            attempt_1 = preds.get('attempt_1', [])
            attempt_2 = preds.get('attempt_2', [])
            # Kaggle expects list of 2 attempts
            submission[base_id] = [
                {"attempt_1": attempt_1},
                {"attempt_2": attempt_2}
            ]

    # Save submission
    output_file = os.path.expanduser("/kaggle/output/submission.json")
    with open(output_file, 'w') as f:
        json.dump(submission, f, indent=2)

    print(f"🎯 SUBMISSION GENERATED")
    print(f"   Tasks included: {len(submission)}")
    print(f"   Saved to: {output_file}")
    print(f"   Next: Upload to Kaggle ARC Prize 2025!")

if __name__ == "__main__":
    create_submission()
