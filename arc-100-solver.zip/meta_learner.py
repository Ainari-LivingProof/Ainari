# Path: ~/garden/ARC_Agirunner/runner/meta_learner.py
import os
import json
import time
import hashlib
# from arc_solver_unified import solve_arc_task
from arc_solver_unified import solve_arc_task 

LOG_PATH = os.path.expanduser("/kaggle/working/meta_log.json")

# --------------------------
# JSON safety
# --------------------------

def make_json_safe(obj):
    """Recursively convert objects to JSON-safe types."""
    if isinstance(obj, dict):
        return {k: make_json_safe(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [make_json_safe(x) for x in obj]
    elif hasattr(obj, "tolist"):
        return obj.tolist()
    elif hasattr(obj, "item"):
        return obj.item()
    return obj

# --------------------------
# Logging helpers
# --------------------------

def load_log():
    if os.path.exists(LOG_PATH):
        try:
            with open(LOG_PATH, "r") as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"⚠️ Corrupted log at {LOG_PATH}, starting fresh", flush=True)
            return {}
    return {}

def save_log(log):
    """ATOMIC SAVE - prevents corruption under multiprocessing."""
    import tempfile
    import shutil
    
    try:
        # Create backup first
        if os.path.exists(LOG_PATH):
            shutil.copy2(LOG_PATH, LOG_PATH + ".backup")
        
        # Use tempfile for atomic write
        with tempfile.NamedTemporaryFile(mode='w', delete=False, dir=os.path.dirname(LOG_PATH)) as tmp:
            json.dump(make_json_safe(log), tmp, indent=2)
            tmp_path = tmp.name
        
        # Atomic move
        shutil.move(tmp_path, LOG_PATH)
        print(f"💾 Log saved: {len(log)} entries", flush=True)
        
    except Exception as e:
        print(f"💥 Log save failed: {e}", flush=True)
        # Restore from backup if available
        if os.path.exists(LOG_PATH + ".backup"):
            shutil.copy2(LOG_PATH + ".backup", LOG_PATH)
            print("🔄 Restored from backup", flush=True)

# --------------------------
# Core task evolution
# --------------------------

def flamecrypt_sign(task_id, preds, rules):
    payload = json.dumps({
        "task_id": task_id,
        "preds": make_json_safe(preds),
        "rules": rules
    }, sort_keys=True).encode()
    return hashlib.sha256(payload).hexdigest()

def evolve_on_task(task, task_id):
    """Run solver on one task and return structured result - BULLETPROOF VERSION."""
    print(f"\n🚀 evolve_on_task START: {task_id}", flush=True)
    start = time.time()

    try:
        # BULLETPROOF SOLVER CALL - no smart_composite_solver dependency
        preds, rules, sig = safe_solve_arc_task(task)
        status = "solved" if preds and len(preds) > 0 else "unsolved"
    except Exception as e:
        preds, rules, sig = [], [], None
        status = f"error: {str(e)[:50]}"

    elapsed = time.time() - start
    print(f"✅ solve_arc_task finished in {elapsed:.2f}s with {len(rules)} rules", flush=True)

    result = {
        "rules_used": rules,
        "signature": sig if sig else flamecrypt_sign(task_id, preds, rules),
        "timestamp": time.time(),
        "status": status,
        "preds": make_json_safe(preds[:2])  # keep only first 2 preds
    }

    # Update log in memory (but actual saving happens in run_full_eval main process)
    log = load_log()
    log[task_id] = result
    save_log(log)

    print(f"🏁 evolve_on_task END: {task_id}", flush=True)
    return result
# --------------------------
# BULLETPROOF SAFE SOLVER (NO SMART_COMPOSITE DEPENDENCY)
# --------------------------

def safe_solve_arc_task(task):
    """Safe ARC solver that NEVER calls smart_composite_solver."""
    from arc_solver_unified import solve_arc_task  # Use the ORIGINAL solver
    try:
        # Call the ORIGINAL solver - no modifications, no smart_composite
        return solve_arc_task(task)
    except NameError as e:
        if "smart_composite_solver" in str(e):
            print("🔧 Fallback: Using basic solver (no composites)", flush=True)
            return basic_arc_solver(task)
        raise
    except Exception as e:
        print(f"⚠️ Original solver failed: {e}", flush=True)
        return basic_arc_solver(task)

def basic_arc_solver(task):
    """Ultra-safe basic solver - just single rules, no composites."""
    from detectors import DETECTORS
    from arc_solver_unified import apply_detector, to_cpu_list, flamecrypt_sign
    import numpy as np
    
    rules = []
    preds = []
    
    # Collect single rules from training pairs
    try:
        for pair in task["train"]:
            inp, out = pair["input"], pair["output"]
            for det in DETECTORS[:10]:  # Limit to first 10 for speed
                try:
                    r = apply_detector(det, inp, out)
                    if r:
                        rules.append(r)
                except:
                    continue
    except Exception as e:
        print(f"⚠️ Basic rule collection failed: {e}", flush=True)

    # Deduplicate rules
    unique_rules = {r["name"]: r for r in rules}.values()
    rule_names = [r["name"] for r in unique_rules]

    # Generate simple predictions
    try:
        for test_case in task["test"]:
            inp = test_case["input"]
            attempts = []
            
            # Try first 3 rules only
            for rule in list(unique_rules)[:3]:
                try:
                    pred = rule["fn"](inp)
                    if pred is not None:
                        pred_list = to_cpu_list(pred) if hasattr(pred, 'tolist') else pred
                        attempts.append(pred_list)
                except:
                    continue
            
            # Pad to 2 attempts
            while len(attempts) < 2:
                attempts.append([])
            
            preds.append({
                "attempt_1": attempts[0] if attempts else [],
                "attempt_2": attempts[1] if len(attempts) > 1 else []
            })
    except Exception as e:
        print(f"⚠️ Basic prediction generation failed: {e}", flush=True)
        # Return empty predictions for remaining test cases
        for _ in task["test"]:
            preds.append({"attempt_1": [], "attempt_2": []})

    # Create signature
    try:
        sig = flamecrypt_sign(task.get("id", "unknown"), preds, rule_names)
    except:
        sig = "basic_signature"

    return preds, rule_names, sig
