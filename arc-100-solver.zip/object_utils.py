import numpy as np
from scipy.ndimage import label, center_of_mass

# --------------------------
# Utility helpers
# --------------------------

def safe_array(grid):
    return np.array(grid, dtype=int)

def extract_objects(arr):
    """Return labeled objects as list of numpy arrays."""
    labeled, num = label(arr != 0)
    objs = []
    for i in range(1, num + 1):
        mask = (labeled == i)
        if np.any(mask):
            objs.append(mask.astype(int) * arr)
    return objs

# --------------------------
# Object functions
# --------------------------

def get_objects(grid):
    """Return all objects as sub-arrays."""
    arr = safe_array(grid)
    return extract_objects(arr)

def get_largest_object(grid):
    """Return the largest object in the grid (by pixel count)."""
    objs = get_objects(grid)
    if not objs:
        return None
    return max(objs, key=lambda o: np.count_nonzero(o))

def align_by_centroid(grid):
    """
    Aligns all objects so their centroid is centered in the grid.
    """
    arr = safe_array(grid)
    labeled, num = label(arr != 0)
    if num == 0:
        return arr

    target = np.zeros_like(arr)
    for i in range(1, num + 1):
        mask = (labeled == i)
        coords = np.argwhere(mask)
        if coords.size == 0:
            continue
        rmin, cmin = coords.min(axis=0)
        rmax, cmax = coords.max(axis=0)
        sub = arr[rmin:rmax+1, cmin:cmax+1]

        # center it
        centroid = np.array(center_of_mass(mask))
        center_r, center_c = np.array(arr.shape) // 2
        shift = (int(center_r - centroid[0]), int(center_c - centroid[1]))

        new_mask = np.zeros_like(arr)
        for (r, c), v in zip(coords, sub.flatten()):
            rr, cc = r + shift[0], c + shift[1]
            if 0 <= rr < arr.shape[0] and 0 <= cc < arr.shape[1]:
                new_mask[rr, cc] = arr[r, c]
        target = np.maximum(target, new_mask)
    return target

def move_object_next_to(grid):
    """
    Move the first object directly adjacent to the second, horizontally.
    """
    arr = safe_array(grid)
    objs = get_objects(arr)
    if len(objs) < 2:
        return None

    o1, o2 = objs[0], objs[1]
    r1, c1 = np.argwhere(o1).min(axis=0)
    r2, c2 = np.argwhere(o2).min(axis=0)

    shift = (0, (c2 - c1) + o2.shape[1])
    target = arr.copy()
    coords = np.argwhere(o1 != 0)
    for r, c in coords:
        rr, cc = r + shift[0], c + shift[1]
        if 0 <= rr < arr.shape[0] and 0 <= cc < arr.shape[1]:
            target[rr, cc] = arr[r, c]
    return target

def highlight_contained_object(grid):
    """
    Highlight an object fully contained inside another.
    """
    arr = safe_array(grid)
    objs = get_objects(arr)
    if len(objs) < 2:
        return None
    for i, o1 in enumerate(objs):
        for j, o2 in enumerate(objs):
            if i != j:
                if np.all((o1 != 0) <= (o2 != 0)):  # o1 inside o2
                    return (o1 != 0).astype(int)
    return None

def copy_nearby_object(grid):
    """
    Duplicate the nearest object next to itself.
    """
    arr = safe_array(grid)
    objs = get_objects(arr)
    if not objs:
        return None
    o = objs[0]
    coords = np.argwhere(o != 0)
    shift = (0, o.shape[1] + 1)
    target = arr.copy()
    for r, c in coords:
        rr, cc = r + shift[0], c + shift[1]
        if 0 <= rr < arr.shape[0] and 0 <= cc < arr.shape[1]:
            target[rr, cc] = arr[r, c]
    return target

def remove_duplicates(grid):
    """
    Remove duplicate objects (keep only unique patterns).
    """
    arr = safe_array(grid)
    objs = get_objects(arr)
    seen = []
    target = np.zeros_like(arr)
    for o in objs:
        if any(np.array_equal(o, s) for s in seen):
            continue
        seen.append(o)
        target = np.maximum(target, o)
    return target

