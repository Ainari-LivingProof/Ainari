# Path: ~/garden/ARC_Agirunner/runner/number_utils.py
import numpy as np

# --------------------------
# Numeric / Arithmetic Helpers
# --------------------------

def detect_parity(inp, out):
    """
    Detects if the transformation recolors based on parity (odd/even row/col).
    """
    inp, out = np.array(inp), np.array(out)
    if inp.shape != out.shape:
        return None

    # Check if even/odd rows or cols are recolored consistently
    even_rows = out[::2, :] 
    odd_rows = out[1::2, :] if out.shape[0] > 1 else []
    even_cols = out[:, ::2] 
    odd_cols = out[:, 1::2] if out.shape[1] > 1 else []

    # If every even row differs consistently
    if even_rows.size > 0 and np.all(even_rows != inp[::2, :]):
        def rule(grid, target_shape=out.shape):
            arr = np.array(grid)
            result = arr.copy()
            result[::2, :] = np.max(arr)  # recolor even rows
            return result.tolist()
        return {"fn": rule, "cost": 2, "name": "parity_row_recolor"}

    if even_cols.size > 0 and np.all(even_cols != inp[:, ::2]):
        def rule(grid, target_shape=out.shape):
            arr = np.array(grid)
            result = arr.copy()
            result[:, ::2] = np.max(arr)  # recolor even cols
            return result.tolist()
        return {"fn": rule, "cost": 2, "name": "parity_col_recolor"}

    return None


def detect_modular_pattern(inp, out):
    """
    Detect if output depends on (row+col) mod k or row mod k / col mod k.
    Useful for stripes, checkerboards, periodic fills.
    """
    inp, out = np.array(inp), np.array(out)
    if inp.shape != out.shape:
        return None

    for k in range(2, 6):  # try small modulus
        if np.all(out == ((np.indices(out.shape).sum(axis=0) % k) + 1)):
            def rule(grid, k=k, target_shape=out.shape):
                h, w = target_shape
                pattern = (np.indices((h, w)).sum(axis=0) % k) + 1
                return pattern.tolist()
            return {"fn": rule, "cost": 3, "name": f"checkerboard_mod{k}"}

    return None


def detect_sequence_fill(inp, out):
    """
    Detects sequential numbering or coloring across rows/cols.
    """
    inp, out = np.array(inp), np.array(out)
    if inp.shape != out.shape:
        return None

    # Check if rows are incremental
    diffs = np.diff(out, axis=0)
    if np.all((diffs == 1) | (diffs == 0)):
        def rule(grid, target_shape=out.shape):
            h, w = target_shape
            result = np.zeros((h, w), dtype=int)
            for i in range(h):
                result[i, :] = (i + 1)
            return result.tolist()
        return {"fn": rule, "cost": 3, "name": "row_sequence_fill"}

    # Check if cols are incremental
    diffs = np.diff(out, axis=1)
    if np.all((diffs == 1) | (diffs == 0)):
        def rule(grid, target_shape=out.shape):
            h, w = target_shape
            result = np.zeros((h, w), dtype=int)
            for j in range(w):
                result[:, j] = (j + 1)
            return result.tolist()
        return {"fn": rule, "cost": 3, "name": "col_sequence_fill"}

    return None


# --------------------------
# Registry
# --------------------------
NUMERIC_DETECTORS = [
    detect_parity,
    detect_modular_pattern,
    detect_sequence_fill
]

