import os
import json
import numpy as np
import time

LOG_FILE = os.path.expanduser("/kaggle/working/meta_log.json")
TASKS_FILE = os.path.expanduser("/kaggle/input/ainariislife/arc_120_eval_compact.json")

def load_ledger_and_tasks():
    try:
        with open(TASKS_FILE, "r") as f:
            tasks = json.load(f)
        return tasks, {t["id"]: t for t in tasks}
    except Exception as e:
        print(f"⚠️ Failed to load tasks: {e}", flush=True)
        return [], {}

def load_log():
    if os.path.exists(LOG_FILE):
        try:
            with open(LOG_FILE, "r") as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_log(log):
    try:
        with open(LOG_FILE, "w") as f:
            json.dump(log, f, indent=2)
    except Exception as e:
        print(f"⚠️ Failed to save log: {e}", flush=True)

def enhanced_second_pass(targets):
    """Safe enhanced corrections - minimal version."""
    log = load_log()
    corrections = {}
    
    print("🔍 Running safe enhanced corrections...", flush=True)
    
    for tid, task in list(targets.items())[:20]:  # Limit to 20 for safety
        try:
            if tid in log and log[tid]["status"].startswith("solved"):
                continue
                
            if not task.get("train"):
                continue
                
            inp = np.array(task["train"][0]["input"])
            out = np.array(task["train"][0]["output"])
            
            # Safe corrections only
            correction = try_safe_corrections(inp, out)
            if correction:
                corrections[tid] = correction
                print(f"✅ [{tid}] Safe correction: {correction['status']}", flush=True)
                
        except Exception as e:
            print(f"⚠️ [{tid}] Correction failed: {e}", flush=True)
            continue
    
    print(f"📊 Safe corrections found: {len(corrections)}", flush=True)
    return corrections

def try_safe_corrections(inp, out):
    """Safe correction strategies - no scipy."""
    strategies = [
        ("color_swap", detect_color_swap_safe),
        ("repeat", detect_repeat_safe),
        ("transpose", detect_transpose_safe),
    ]
    
    for name, strategy in strategies:
        try:
            result = strategy(inp, out)
            if result:
                return {
                    "status": f"solved_{name}",
                    "rules_used": [name],
                }
        except:
            continue
    return None

def detect_color_swap_safe(inp, out):
    """Safe color swap detection."""
    inp, out = np.array(inp), np.array(out)
    if inp.shape != out.shape:
        return None
    
    color_map = {}
    for i_val, o_val in zip(inp.flatten(), out.flatten()):
        if i_val != 0 and o_val != 0 and i_val != o_val:
            if i_val in color_map and color_map[i_val] != o_val:
                return None
            color_map[i_val] = o_val
    
    if color_map:
        return True
    return None

def detect_repeat_safe(inp, out):
    """Safe repeat detection."""
    inp, out = np.array(inp), np.array(out)
    if out.shape[0] % inp.shape[0] == 0 and out.shape[1] == inp.shape[1]:
        reps = out.shape[0] // inp.shape[0]
        for i in range(reps):
            if not np.array_equal(out[i*inp.shape[0]:(i+1)*inp.shape[0]], inp):
                break
        else:
            return True
    return None

def detect_transpose_safe(inp, out):
    """Your original transpose."""
    inp, out = np.array(inp), np.array(out)
    if inp.T.shape == out.shape and np.array_equal(inp.T, out):
        return True
    return None

def generate_final_predictions(enhanced_results):
    """Safe prediction generation."""
    preds = {}
    for tid, info in enhanced_results.items():
        preds[tid] = {"status": info["status"], "rules": info["rules_used"]}
    return preds

def update_ledger(enhanced_results):
    """Safe ledger update."""
    log = load_log()
    updated = 0
    
    for tid, info in enhanced_results.items():
        if tid not in log or not log[tid]["status"].startswith("solved"):
            log[tid] = {
                "rules_used": info["rules_used"],
                "signature": f"safe_enhanced_{tid}",
                "timestamp": time.time(),
                "status": info["status"],
            }
            updated += 1
    
    save_log(log)
    print(f"✅ Safe correction updated {updated} tasks", flush=True)
