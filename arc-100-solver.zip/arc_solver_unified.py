import torch
import numpy as np
import hashlib
import time
import json
from detectors import DETECTORS
from transform_utils import to_tensor, to_cpu_list

DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# --------------------------
# JSON-safe signer
# --------------------------

def flamecrypt_sign(task_id, preds, rules):
    """Create a JSON-safe signature of predictions and rules."""
    def make_json_safe(obj):
        if isinstance(obj, torch.Tensor):
            return obj.detach().cpu().tolist()
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {k: make_json_safe(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [make_json_safe(x) for x in obj]
        elif isinstance(obj, tuple):
            return tuple(make_json_safe(x) for x in obj)
        else:
            return obj

    payload = {
        "task_id": task_id,
        "preds": make_json_safe(preds),
        "rules": make_json_safe(rules),
    }
    raw = json.dumps(payload, sort_keys=True).encode()

    return hashlib.sha256(raw).hexdigest()

# --------------------------
# Rule application
# --------------------------

def apply_detector(detector, inp, out):
    """
    Apply a single detector function to GPU tensors.
    Detectors expect CPU lists, so we pass .tolist(),
    then wrap the fn so it returns GPU tensors.
    """
    try:
        r = detector(to_cpu_list(inp), to_cpu_list(out))
        if r:
            def gpu_rule(grid):
                arr = to_tensor(grid)
                result = r["fn"](to_cpu_list(arr))  # detectors work on CPU lists
                return to_tensor(result)
            return {"fn": gpu_rule, "cost": r.get("cost", 1), "name": r["name"]}
    except Exception as e:
        print(f"⚠️ apply_detector failed: {e}", flush=True)
        return None
    return None

def apply_rules(rules, inp):
    """Apply a sequence of rules to an input GPU tensor."""
    arr = to_tensor(inp)
    for r in rules:
        try:
            arr = r["fn"](arr)
        except Exception as e:
            print(f"⚠️ apply_rules failed on {r['name']}: {e}", flush=True)
            return None
    return arr

# --------------------------
# ORIGINAL SOLVER (NO SMART COMPOSITE)
# --------------------------

def solve_arc_task(task):
    """
    Attempt to solve an ARC task using detectors and GPU acceleration.
    Returns predictions as JSON-safe lists.
    """
    rules = []
    start = time.time()
    task_id = task.get("id", "unknown")

    print(f"\n🚀 Solving {task_id}: {len(task['train'])} train, {len(task['test'])} test", flush=True)

    # Collect candidate rules from training pairs
    try:
        for i, pair in enumerate(task["train"]):
            inp, out = pair["input"], pair["output"]
            print(f"   Training pair {i+1}: checking detectors")
            
            for det in DETECTORS:
                try:
                    r = apply_detector(det, inp, out)
                    if r and r["name"] not in [sr["name"] for sr in rules]:
                        rules.append(r)
                except Exception as e:
                    continue  # Skip failed detectors

        print(f"   Found {len(rules)} unique rules", flush=True)
        
    except Exception as e:
        print(f"⚠️ Error in rule collection: {e}", flush=True)

    # Generate predictions for test cases - FIXED VERSION
    preds = []
    try:
        for test_idx, test_case in enumerate(task["test"]):
            test_input = test_case["input"]  # ✅ ONLY INPUT - no output for test cases
            
            attempts = []
            
            # Try each rule on the TEST INPUT
            for rule in rules[:3]:  # Limit to first 3 rules for speed
                try:
                    pred = rule["fn"](test_input)  # ✅ Apply to test input
                    
                    # Convert to JSON-safe list
                    if pred is not None:
                        pred_list = to_cpu_list(pred) if hasattr(pred, 'tolist') else pred
                        attempts.append(pred_list)
                        
                except Exception as e:
                    print(f"⚠️ Rule {rule['name']} failed on test case {test_idx}: {e}", flush=True)
                    continue
            
            # Fallback: if no rules work, copy the input as prediction
            if not attempts:
                print(f"   Test case {test_idx}: No rules worked, using input as fallback")
                fallback = [row[:] for row in test_input]  # Deep copy input
                attempts.append(fallback)
            
            # Ensure exactly 2 attempts
            while len(attempts) < 2:
                attempts.append(attempts[0] if attempts else [])  # Duplicate first attempt
            
            # Store the predictions
            preds.append({
                "attempt_1": attempts[0],
                "attempt_2": attempts[1]
            })
            
            print(f"   Test case {test_idx+1}: Generated {len(attempts[0])}x{len(attempts[0][0] if attempts[0] else 0)} prediction")
    
    except Exception as e:
        print(f"💥 Test prediction generation failed: {e}", flush=True)
        # Emergency fallback: copy inputs for all test cases
        for test_case in task["test"]:
            fallback = [row[:] for row in test_case["input"]]
            preds.append({
                "attempt_1": fallback,
                "attempt_2": fallback
            })

    # Create JSON-safe signature
    try:
        rule_names = [r["name"] for r in rules]
        sig = flamecrypt_sign(task_id, preds, rule_names)
    except Exception as e:
        print(f"⚠️ flamecrypt_sign failed: {e}", flush=True)
        sig = "signature_error"

    elapsed = time.time() - start
    print(f"✅ solve_arc_task finished in {elapsed:.2f}s | {len(preds)} predictions | {len(rules)} rules", flush=True)

    # Always return a triple
    return preds, [r["name"] for r in rules], sig
