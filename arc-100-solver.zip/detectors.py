# Path: ~/garden/ARC_Agirunner/runner/detectors.py
import numpy as np
from number_utils import NUMERIC_DETECTORS
from object_utils import (
    get_objects,
    get_largest_object,
    align_by_centroid,
    move_object_next_to,
    highlight_contained_object,
    copy_nearby_object,
    remove_duplicates,
)

# --------------------------
# Utilities
# --------------------------

def safe_array(grid):
    return np.array(grid, dtype=int)

def wrap_detector(name, fn, cost=1):
    """Helper to wrap rule into detector format."""
    return {"fn": fn, "cost": cost, "name": name}

# --------------------------
# Baseline detectors
# --------------------------
def resize_grid(grid, new_shape):
    """
    Resize a grid to new_shape using nearest-neighbor scaling.
    """
    arr = safe_array(grid)
    out_r, out_c = new_shape
    in_r, in_c = arr.shape

    row_idx = (np.linspace(0, in_r - 1, out_r)).astype(int)
    col_idx = (np.linspace(0, in_c - 1, out_c)).astype(int)
    resized = arr[row_idx[:, None], col_idx]
    return resized.tolist()

def detect_identity(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None

    def rule(grid):
        return safe_array(grid).tolist()

    if np.array_equal(rule(inp), out):
        return wrap_detector("detect_identity", rule, 1)
    return None


def detect_flip(inp, out):
    inp, out = safe_array(inp), safe_array(out)

    def rule_lr(grid):
        return np.fliplr(safe_array(grid)).tolist()
    if np.array_equal(rule_lr(inp), out):
        return wrap_detector("detect_flip_lr", rule_lr, 1)

    def rule_ud(grid):
        return np.flipud(safe_array(grid)).tolist()
    if np.array_equal(rule_ud(inp), out):
        return wrap_detector("detect_flip_ud", rule_ud, 1)

    return None


def detect_rotate(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    for k in range(1, 4):
        def rule(grid, k=k):
            return np.rot90(safe_array(grid), k=k).tolist()
        if np.array_equal(rule(inp), out):
            return wrap_detector(f"detect_rotate_{k*90}", rule, k)
    return None


def detect_translation(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None
    nz_in, nz_out = np.argwhere(inp != 0), np.argwhere(out != 0)
    if len(nz_in) == 0 or len(nz_out) == 0:
        return None
    offset = tuple(nz_out[0] - nz_in[0])

    def rule(grid):
        arr = safe_array(grid)
        shifted = np.zeros_like(arr)
        for r, c in np.argwhere(arr != 0):
            rr, cc = r + offset[0], c + offset[1]
            if 0 <= rr < arr.shape[0] and 0 <= cc < arr.shape[1]:
                shifted[rr, cc] = arr[r, c]
        return shifted.tolist()

    if np.array_equal(rule(inp), out):
        return wrap_detector(f"detect_translation_{offset}", rule, 2)
    return None
# --------------------------
# Scaling + shape/color transforms
# --------------------------

def detect_scale(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if out.shape[0] % inp.shape[0] != 0 or out.shape[1] % inp.shape[1] != 0:
        return None
    fx, fy = out.shape[0] // inp.shape[0], out.shape[1] // inp.shape[1]
    if fx != fy or fx <= 1:
        return None

    def rule(grid):
        arr = safe_array(grid)
        return arr.repeat(fx, axis=0).repeat(fy, axis=1).tolist()

    if np.array_equal(rule(inp), out):
        return wrap_detector(f"detect_scale_{fx}x", rule, fx)
    return None


def detect_mirror_shape(inp, out):
    inp, out = safe_array(inp), safe_array(out)

    def rule_lr(grid):
        arr = safe_array(grid)
        return np.concatenate([arr, np.fliplr(arr)], axis=1).tolist()

    if out.shape == safe_array(rule_lr(inp)).shape and np.array_equal(rule_lr(inp), out):
        return wrap_detector("detect_mirror_lr", rule_lr, 2)

    def rule_ud(grid):
        arr = safe_array(grid)
        return np.concatenate([arr, np.flipud(arr)], axis=0).tolist()

    if out.shape == safe_array(rule_ud(inp)).shape and np.array_equal(rule_ud(inp), out):
        return wrap_detector("detect_mirror_ud", rule_ud, 2)

    return None


def detect_recolor(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None
    mapping = {}
    for i_val, o_val in zip(inp.flatten(), out.flatten()):
        if i_val != o_val:
            mapping[i_val] = o_val
    if not mapping:
        return None

    def rule(grid):
        arr = safe_array(grid)
        return np.vectorize(lambda v: mapping.get(v, v))(arr).tolist()

    if np.array_equal(rule(inp), out):
        return wrap_detector(f"detect_recolor_{mapping}", rule, 1)
    return None


def detect_symmetry_fill(inp, out):
    inp, out = safe_array(inp), safe_array(out)

    def rule_lr(grid):
        arr = safe_array(grid)
        return np.maximum(arr, np.fliplr(arr)).tolist()

    if np.array_equal(rule_lr(inp), out):
        return wrap_detector("detect_symmetry_fill_lr", rule_lr, 2)

    def rule_ud(grid):
        arr = safe_array(grid)
        return np.maximum(arr, np.flipud(arr)).tolist()

    if np.array_equal(rule_ud(inp), out):
        return wrap_detector("detect_symmetry_fill_ud", rule_ud, 2)

    return None


def detect_crop(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    sub = inp[np.any(inp != 0, axis=1)][:, np.any(inp != 0, axis=0)]
    if sub.shape == out.shape and np.array_equal(sub, out):
        def rule(grid):
            arr = safe_array(grid)
            return arr[np.any(arr != 0, axis=1)][:, np.any(arr != 0, axis=0)].tolist()
        return wrap_detector("detect_crop", rule, 2)
    return None


def detect_pad(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape[0] > out.shape[0] or inp.shape[1] > out.shape[1]:
        return None
    pad_r, pad_c = out.shape[0] - inp.shape[0], out.shape[1] - inp.shape[1]

    def rule(grid):
        arr = safe_array(grid)
        return np.pad(arr, ((0, pad_r), (0, pad_c)), constant_values=0).tolist()

    if np.array_equal(rule(inp), out):
        return wrap_detector(f"detect_pad_{pad_r}x{pad_c}", rule, 2)
    return None


def detect_bounding_box(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    nz = np.argwhere(inp != 0)
    if nz.size == 0:
        return None
    rmin, cmin = nz.min(axis=0)
    rmax, cmax = nz.max(axis=0)

    def rule(grid):
        arr = safe_array(grid)
        bb = np.zeros_like(arr)
        bb[rmin:rmax+1, cmin:cmax+1] = 1
        return bb.tolist()

    if np.array_equal(rule(inp), out):
        return wrap_detector("detect_bounding_box", rule, 2)
    return None


def detect_flood_fill(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None

    def rule(grid):
        arr = safe_array(grid)
        filled = (arr != 0).astype(int)
        return filled.tolist()

    if np.array_equal(rule(inp), out):
        return wrap_detector("detect_flood_fill", rule, 2)
    return None
# --------------------------
# Fill + pattern detectors
# --------------------------

def detect_fill_gaps(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None

    def rule(grid):
        arr = safe_array(grid)
        filled = arr.copy()
        mask = (filled == 0)
        if np.any(mask):
            filled[mask] = np.bincount(arr.flatten())[1:].argmax() + 1
        return filled.tolist()

    if np.array_equal(rule(inp), out):
        return wrap_detector("detect_fill_gaps", rule, 2)
    return None


def detect_diagonal_fill(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    diag = np.diag(inp)
    new = inp.copy()
    np.fill_diagonal(new, diag[0])

    if np.array_equal(new, out):
        def rule(grid):
            arr = safe_array(grid)
            d = np.diag(arr)
            arr2 = arr.copy()
            np.fill_diagonal(arr2, d[0])
            return arr2.tolist()
        return wrap_detector("detect_diagonal_fill", rule, 2)
    return None


def detect_grid_fold(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape[0] % 2 != 0 or inp.shape[1] % 2 != 0:
        return None
    half_r, half_c = inp.shape[0] // 2, inp.shape[1] // 2
    folded = inp[:half_r, :half_c] + inp[half_r:, half_c:]
    if folded.shape == out.shape and np.array_equal(folded, out):
        def rule(grid):
            arr = safe_array(grid)
            hr, hc = arr.shape[0] // 2, arr.shape[1] // 2
            return (arr[:hr, :hc] + arr[hr:, hc:]).tolist()
        return wrap_detector("detect_grid_fold", rule, 3)
    return None


def detect_fill_pattern(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if out.shape[0] % inp.shape[0] != 0 or out.shape[1] % inp.shape[1] != 0:
        return None
    fx, fy = out.shape[0] // inp.shape[0], out.shape[1] // inp.shape[1]
    tiled = np.tile(inp, (fx, fy))
    if np.array_equal(tiled, out):
        def rule(grid):
            arr = safe_array(grid)
            return np.tile(arr, (fx, fy)).tolist()
        return wrap_detector("detect_fill_pattern", rule, 3)
    return None

# --------------------------
# Object-based detectors
# --------------------------

def detect_align_by_centroid(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    aligned = align_by_centroid(inp)
    if np.array_equal(aligned, out):
        def rule(grid):
            return align_by_centroid(safe_array(grid)).tolist()
        return wrap_detector("detect_align_by_centroid", rule, 3)
    return None


def detect_move_object_next_to(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    moved = move_object_next_to(inp)
    if moved is not None and np.array_equal(moved, out):
        def rule(grid):
            return move_object_next_to(safe_array(grid)).tolist()
        return wrap_detector("detect_move_object_next_to", rule, 3)
    return None


def detect_contained_object_highlight(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    highlighted = highlight_contained_object(inp)
    if highlighted is not None and np.array_equal(highlighted, out):
        def rule(grid):
            return highlight_contained_object(safe_array(grid)).tolist()
        return wrap_detector("detect_contained_object_highlight", rule, 3)
    return None


def detect_copy_nearby(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    copied = copy_nearby_object(inp)
    if copied is not None and np.array_equal(copied, out):
        def rule(grid):
            return copy_nearby_object(safe_array(grid)).tolist()
        return wrap_detector("detect_copy_nearby", rule, 3)
    return None


def detect_remove_duplicates(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    dedup = remove_duplicates(inp)
    if dedup is not None and np.array_equal(dedup, out):
        def rule(grid):
            return remove_duplicates(safe_array(grid)).tolist()
        return wrap_detector("detect_remove_duplicates", rule, 2)
    return None
# --------------------------
# Semantic + advanced detectors
# --------------------------

def detect_semantic_fill(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None
    dominant = np.bincount(out.flatten()).argmax()

    def rule(grid):
        arr = safe_array(grid)
        filled = arr.copy()
        filled[arr == 0] = dominant
        return filled.tolist()

    if np.array_equal(rule(inp), out):
        return wrap_detector("detect_semantic_fill", rule, 3)
    return None


def detect_inside_fill(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    mask = (inp != 0)
    if np.array_equal(np.where(mask, 1, 0), out):
        def rule(grid):
            arr = safe_array(grid)
            return np.where(arr != 0, 1, 0).tolist()
        return wrap_detector("detect_inside_fill", rule, 2)
    return None


def detect_repeat_object(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    objs = get_objects(inp)
    if not objs:
        return None
    obj = objs[0]
    tiled = np.tile(obj, (out.shape[0] // obj.shape[0], out.shape[1] // obj.shape[1]))
    if tiled.shape == out.shape and np.array_equal(tiled, out):
        def rule(grid):
            objs2 = get_objects(safe_array(grid))
            if not objs2:
                return safe_array(grid).tolist()
            o = objs2[0]
            return np.tile(o, (out.shape[0] // o.shape[0], out.shape[1] // o.shape[1])).tolist()
        return wrap_detector("detect_repeat_object", rule, 3)
    return None


def detect_stable_fill(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    filled = np.where(inp != 0, inp, np.max(inp))
    if np.array_equal(filled, out):
        def rule(grid):
            arr = safe_array(grid)
            return np.where(arr != 0, arr, np.max(arr)).tolist()
        return wrap_detector("detect_stable_fill", rule, 2)
    return None


def detect_color_cycle(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None
    unique = np.unique(inp)
    mapping = {val: (i+1) % len(unique) for i, val in enumerate(unique)}

    def rule(grid):
        arr = safe_array(grid)
        return np.vectorize(lambda v: mapping.get(v, v))(arr).tolist()

    if np.array_equal(rule(inp), out):
        return wrap_detector("detect_color_cycle", rule, 3)
    return None

def detect_fibonacci_fill(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None

    fib = [0, 1]
    while len(fib) < inp.size:
        fib.append(fib[-1] + fib[-2])
    fib_arr = np.array(fib[:inp.size]).reshape(inp.shape)

    if np.array_equal(fib_arr, out):
        def rule(grid):
            fib = [0, 1]
            while len(fib) < grid.size:
                fib.append(fib[-1] + fib[-2])
            return np.array(fib[:grid.size]).reshape(grid.shape).tolist()
        return wrap_detector("detect_fibonacci_fill", rule, 5)
    return None

def detect_arithmetic_repeat(inp, out):
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None
    diffs = np.diff(out.flatten())
    if np.all(diffs == diffs[0]):
        def rule(grid):
            flat = grid.flatten()
            d = np.diff(flat)
            if len(d) == 0:
                return grid.tolist()
            step = d[0]
            seq = [flat[0] + i*step for i in range(flat.size)]
            return np.array(seq).reshape(grid.shape).tolist()
        return wrap_detector("detect_arithmetic_repeat", rule, 4)
    return None
    
def detect_core_extension_safe(inp, out):
    """Safe version: detect if output extends input pattern."""
    inp, out = safe_array(inp), safe_array(out)
    if out.shape[0] < inp.shape[0] or out.shape[1] < inp.shape[1]:
        return None
    
    # Simple top-left containment check
    if (out.shape[0] >= inp.shape[0] and out.shape[1] >= inp.shape[1] and
        np.array_equal(out[:inp.shape[0], :inp.shape[1]], inp)):
        
        # Extension is the new parts
        ext_r = out[inp.shape[0]:, :inp.shape[1]] if out.shape[0] > inp.shape[0] else None
        ext_c = out[:inp.shape[0], inp.shape[1]:] if out.shape[1] > inp.shape[1] else None
        
        def rule(grid, ext_r=ext_r, ext_c=ext_c):
            arr = safe_array(grid)
            h, w = arr.shape
            if ext_r is None and ext_c is None:
                return arr.tolist()
            result = np.zeros((max(h, out.shape[0]), max(w, out.shape[1])), dtype=int)
            result[:h, :w] = arr
            if ext_r is not None and ext_r.size > 0:
                result[h:h+ext_r.shape[0], :w] = ext_r
            if ext_c is not None and ext_c.size > 0:
                result[:h, w:w+ext_c.shape[1]] = ext_c
            return result.tolist()
        
        return wrap_detector("detect_core_ext_safe", rule, 3)
    return None

def detect_repeat_simple(inp, out):
    """Safe repetition detector."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Check row repetition
    if out.shape[0] % inp.shape[0] == 0 and out.shape[1] == inp.shape[1]:
        reps = out.shape[0] // inp.shape[0]
        for i in range(reps):
            if not np.array_equal(out[i*inp.shape[0]:(i+1)*inp.shape[0]], inp):
                break
        else:
            def rule(grid, reps=reps):
                arr = safe_array(grid)
                h_base, w = arr.shape
                return np.tile(arr, (reps, 1)).tolist()
            return wrap_detector(f"detect_row_repeat_{reps}x", rule, 3)
    
    return None

def detect_color_swap(inp, out):
    """Safe color swapping detector."""
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None
    
    # Find consistent color swaps
    color_map = {}
    for i_val, o_val in zip(inp.flatten(), out.flatten()):
        if i_val != 0 and o_val != 0 and i_val != o_val:
            if i_val in color_map and color_map[i_val] != o_val:
                return None  # Inconsistent mapping
            color_map[i_val] = o_val
    
    if color_map:
        def rule(grid):
            arr = safe_array(grid)
            return np.vectorize(lambda v: color_map.get(v, v))(arr).tolist()
        return wrap_detector(f"detect_color_swap_{len(color_map)}", rule, 2)
    
    return None
    
def detect_core_extension(inp, out):
    """Detect if output extends the core pattern of input - ARC-2 favorite!"""
    inp, out = safe_array(inp), safe_array(out)
    if out.shape[0] < inp.shape[0] or out.shape[1] < inp.shape[1]:
        return None
    
    # Check if output contains input as a subgrid (top-left placement is most common)
    positions = [(0, 0), (0, out.shape[1]-inp.shape[1]), 
                 (out.shape[0]-inp.shape[0], 0), (out.shape[0]-inp.shape[0], out.shape[1]-inp.shape[1])]
    
    for dr, dc in positions:
        r_start, c_start = dr, dc
        r_end, c_end = r_start + inp.shape[0], c_start + inp.shape[1]
        
        # Check if input fits in this position
        if (r_end <= out.shape[0] and c_end <= out.shape[1] and 
            np.array_equal(out[r_start:r_end, c_start:c_end], inp)):
            
            # Extract the extension pattern (the new parts)
            ext_pattern = None
            if dr > 0 or dc > 0:  # There's an extension
                # Simple extension: repeat the border pattern
                ext_pattern = inp[-1, -1] if dr > 0 and dc > 0 else inp[0, 0]
                
            def rule(grid, ext_pattern=ext_pattern, dr=dr, dc=dc):
                arr = safe_array(grid)
                h, w = arr.shape
                # Create extended grid
                new_h = max(h, out.shape[0])
                new_w = max(w, out.shape[1])
                result = np.zeros((new_h, new_w), dtype=int)
                # Place original grid
                result[:h, :w] = arr
                # Add extension if needed
                if ext_pattern is not None:
                    if dr > 0:  # Extend downward
                        result[h:, :w] = ext_pattern
                    if dc > 0:  # Extend rightward
                        result[:h, w:] = ext_pattern
                return result.tolist()
            
            return wrap_detector(f"core_ext_{dr},{dc}", rule, 3)
    
    return None


def detect_connect_components(inp, out):
    """Connect disconnected components of same color - common ARC-2 pattern."""
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None
    
    # Simple connectivity: fill gaps between same-color pixels (3x3 neighborhood)
    unique_colors = np.unique(inp[inp != 0])
    connected = inp.copy()
    
    # For each color, try to connect nearby pixels
    for color in unique_colors:
        # Find all positions of this color
        positions = np.argwhere(inp == color)
        if len(positions) < 2:
            continue
            
        # Simple flood-fill like connection: expand each pixel by 1
        for r, c in positions:
            # Check 8 neighbors
            for dr in [-1, 0, 1]:
                for dc in [-1, 0, 1]:
                    if dr == 0 and dc == 0:
                        continue
                    nr, nc = r + dr, c + dc
                    if (0 <= nr < inp.shape[0] and 0 <= nc < inp.shape[1] and 
                        connected[nr, nc] == 0 and 
                        np.any(np.abs(positions[:, 0] - nr) + np.abs(positions[:, 1] - nc) <= 2)):
                        connected[nr, nc] = color
    
    if np.array_equal(connected, out):
        def rule(grid):
            arr = safe_array(grid)
            unique_cols = np.unique(arr[arr != 0])
            result = arr.copy()
            
            for col in unique_cols:
                positions = np.argwhere(arr == col)
                if len(positions) < 2:
                    continue
                for r, c in positions:
                    for dr in [-1, 0, 1]:
                        for dc in [-1, 0, 1]:
                            if dr == 0 and dc == 0:
                                continue
                            nr, nc = r + dr, c + dc
                            if (0 <= nr < arr.shape[0] and 0 <= nc < arr.shape[1] and 
                                result[nr, nc] == 0 and 
                                np.any(np.abs(positions[:, 0] - nr) + np.abs(positions[:, 1] - nc) <= 2)):
                                result[nr, nc] = col
            return result.tolist()
        
        return wrap_detector("connect_components", rule, 3)
    
    return None


def detect_repeat_with_variation(inp, out):
    """Detect repetition where each instance has systematic variation."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Strategy 1: Row-wise repetition with color cycling
    if out.shape[0] % inp.shape[0] == 0 and out.shape[1] == inp.shape[1]:
        reps = out.shape[0] // inp.shape[0]
        if reps > 1:
            # Check if each repetition is the same as input
            all_match = True
            for i in range(reps):
                if not np.array_equal(out[i*inp.shape[0]:(i+1)*inp.shape[0]], inp):
                    all_match = False
                    break
            if all_match:
                def rule(grid, reps=reps):
                    arr = safe_array(grid)
                    h_base, w = arr.shape
                    result = np.tile(arr, (reps, 1))
                    return result.tolist()
                return wrap_detector(f"row_repeat_{reps}x", rule, 3)
    
    # Strategy 2: Column-wise repetition
    if out.shape[1] % inp.shape[1] == 0 and out.shape[0] == inp.shape[0]:
        reps = out.shape[1] // inp.shape[1]
        if reps > 1:
            all_match = True
            for i in range(reps):
                if not np.array_equal(out[:, i*inp.shape[1]:(i+1)*inp.shape[1]], inp):
                    all_match = False
                    break
            if all_match:
                def rule(grid, reps=reps):
                    arr = safe_array(grid)
                    h, w_base = arr.shape
                    result = np.tile(arr, (1, reps))
                    return result.tolist()
                return wrap_detector(f"col_repeat_{reps}x", rule, 3)
    
    # Strategy 3: Diagonal repetition (common in ARC-2)
    if out.shape[0] == out.shape[1] and inp.shape[0] == inp.shape[1]:
        n = out.shape[0]
        m = inp.shape[0]
        if n % m == 0:
            reps = n // m
            # Check diagonal blocks
            all_match = True
            for i in range(reps):
                for j in range(reps):
                    block = out[i*m:(i+1)*m, j*m:(j+1)*m]
                    if not np.array_equal(block, inp):
                        all_match = False
                        break
                if not all_match:
                    break
            if all_match:
                def rule(grid, reps=reps):
                    arr = safe_array(grid)
                    m = arr.shape[0]
                    result = np.tile(arr, (reps, reps))
                    return result.tolist()
                return wrap_detector(f"diag_repeat_{reps}x{reps}", rule, 4)
    
    return None
    
def detect_pattern_repeat(inp, out):
    """Aggressive pattern repetition - tiles the dominant pattern."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Find the most common non-zero pattern (2x2 block)
    h, w = inp.shape
    if h < 2 or w < 2:
        return None
    
    # Count 2x2 block occurrences
    block_counts = {}
    for i in range(h-1):
        for j in range(w-1):
            block = tuple(inp[i:i+2, j:j+2].flatten())
            if np.any(block):  # Non-empty block
                block_counts[block] = block_counts.get(block, 0) + 1
    
    if not block_counts:
        return None
    
    # Use most common block
    dominant_block = max(block_counts, key=block_counts.get)
    block_arr = np.array(dominant_block).reshape(2, 2)
    
    # Tile to output size
    if out.shape[0] % 2 == 0 and out.shape[1] % 2 == 0:
        reps_h, reps_w = out.shape[0] // 2, out.shape[1] // 2
        tiled = np.tile(block_arr, (reps_h, reps_w))
        
        if np.array_equal(tiled, out):
            def rule(grid):
                arr = safe_array(grid)
                h, w = arr.shape
                if h < 2 or w < 2:
                    return arr.tolist()
                
                # Find dominant 2x2 block
                block_counts = {}
                for i in range(h-1):
                    for j in range(w-1):
                        block = tuple(arr[i:i+2, j:j+2].flatten())
                        if np.any(block):
                            block_counts[block] = block_counts.get(block, 0) + 1
                
                if block_counts:
                    dom_block = max(block_counts, key=block_counts.get)
                    block_arr = np.array(dom_block).reshape(2, 2)
                    
                    # Tile to match output pattern
                    target_h, target_w = out.shape
                    reps_h, reps_w = target_h // 2, target_w // 2
                    return np.tile(block_arr, (reps_h, reps_w)).tolist()
                return arr.tolist()
            
            return wrap_detector("pattern_repeat_tile", rule, 4)

def detect_border_extension(inp, out):
    """Extend borders with surrounding pattern - common ARC-2 trick."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Check if output is input + border
    if (out.shape[0] == inp.shape[0] + 2 and out.shape[1] == inp.shape[1] + 2):
        # Check if borders match the adjacent input
        top_border = out[0, 1:-1]
        bottom_border = out[-1, 1:-1]
        left_border = out[1:-1, 0]
        right_border = out[1:-1, -1]
        
        input_top = inp[0, :]
        input_bottom = inp[-1, :]
        input_left = inp[:, 0]
        input_right = inp[:, -1]
        
        if (np.array_equal(top_border, input_top) and 
            np.array_equal(bottom_border, input_bottom) and
            np.array_equal(left_border, input_left) and 
            np.array_equal(right_border, input_right)):
            
            def rule(grid):
                arr = safe_array(grid)
                h, w = arr.shape
                # Add border by duplicating edges
                result = np.zeros((h+2, w+2), dtype=int)
                result[1:-1, 1:-1] = arr  # Center is original
                result[0, 1:-1] = arr[0, :]  # Top border
                result[-1, 1:-1] = arr[-1, :]  # Bottom border  
                result[1:-1, 0] = arr[:, 0]  # Left border
                result[1:-1, -1] = arr[:, -1]  # Right border
                # Corners
                result[0, 0] = arr[0, 0]
                result[0, -1] = arr[0, -1]
                result[-1, 0] = arr[-1, 0]
                result[-1, -1] = arr[-1, -1]
                return result.tolist()
            
            return wrap_detector("border_extension", rule, 3)

def detect_color_gradient(inp, out):
    """Create gradients between colors - sneaky ARC-2 pattern."""
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None
    
    # Check if output creates gradients between input colors
    unique_in = np.unique(inp)
    unique_out = np.unique(out)
    
    if len(unique_in) < 2 or len(unique_out) < 2:
        return None
    
    # Simple gradient: interpolate between two dominant colors
    color1 = np.bincount(inp.flatten()).argmax()
    color2 = np.bincount(out.flatten()).argmax()
    
    if color1 == 0 or color2 == 0:
        return None
    
    # Create row-wise gradient
    gradient = np.zeros_like(inp)
    for i in range(inp.shape[0]):
        t = i / (inp.shape[0] - 1) if inp.shape[0] > 1 else 0.5
        gradient[i, :] = int(color1 * (1-t) + color2 * t)
    
    if np.array_equal(gradient, out):
        def rule(grid):
            arr = safe_array(grid)
            if arr.shape[0] < 2:
                return arr.tolist()
            
            # Find dominant colors
            counts = np.bincount(arr.flatten())
            if len(counts) < 2:
                return arr.tolist()
            
            color1 = np.argmax(counts[1:]) + 1  # Most common non-zero
            color2 = np.argsort(counts)[-2] + 1 if len(np.unique(arr)) > 2 else color1  # Second most common
            
            gradient = np.zeros_like(arr)
            for i in range(arr.shape[0]):
                t = i / (arr.shape[0] - 1) if arr.shape[0] > 1 else 0.5
                gradient[i, :] = int(color1 * (1-t) + color2 * t)
            return gradient.tolist()
        
        return wrap_detector("color_gradient", rule, 4)

def detect_downsample(inp, out):
    """Downsample/compress large grids to smaller patterns."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Check if output is a downsampled version of input
    if out.shape[0] * 2 <= inp.shape[0] and out.shape[1] * 2 <= inp.shape[1]:
        factor_h, factor_w = inp.shape[0] // out.shape[0], inp.shape[1] // out.shape[1]
        
        # Simple average pooling
        pooled = np.zeros(out.shape, dtype=int)
        for i in range(out.shape[0]):
            for j in range(out.shape[1]):
                block = inp[i*factor_h:(i+1)*factor_h, j*factor_w:(j+1)*factor_w]
                # Take most common value in block
                pooled[i, j] = np.bincount(block.flatten()).argmax()
        
        if np.array_equal(pooled, out):
            def rule(grid, factor_h=factor_h, factor_w=factor_w):
                arr = safe_array(grid)
                if arr.shape[0] <= factor_h or arr.shape[1] <= factor_w:
                    return arr.tolist()
                
                target_h, target_w = arr.shape[0] // factor_h, arr.shape[1] // factor_w
                result = np.zeros((target_h, target_w), dtype=int)
                
                for i in range(target_h):
                    for j in range(target_w):
                        block = arr[i*factor_h:(i+1)*factor_h, j*factor_w:(j+1)*factor_w]
                        result[i, j] = np.bincount(block.flatten()).argmax()
                
                return result.tolist()
            return wrap_detector(f"downsample_{factor_h}x{factor_w}", rule, 4)
    
    return None


def detect_subgrid_extract(inp, out):
    """Extract a subgrid or representative pattern."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Try extracting a subgrid that matches output
    h, w = inp.shape
    oh, ow = out.shape
    
    # Check all possible subgrids of output size
    for start_r in range(h - oh + 1):
        for start_c in range(w - ow + 1):
            subgrid = inp[start_r:start_r+oh, start_c:start_c+ow]
            if np.array_equal(subgrid, out):
                def rule(grid, start_r=start_r, start_c=start_c, oh=oh, ow=ow):
                    arr = safe_array(grid)
                    if arr.shape[0] < oh or arr.shape[1] < ow:
                        return arr.tolist()
                    # Extract same relative subgrid
                    return arr[start_r:start_r+oh, start_c:start_c+ow].tolist()
                
                return wrap_detector(f"subgrid_{start_r},{start_c}", rule, 2)
    
    # Try taking every Nth row/column
    if h >= oh and w >= ow:
        for step_h in range(1, min(4, h//oh + 1)):
            for step_w in range(1, min(4, w//ow + 1)):
                extracted = inp[::step_h, ::step_w]
                if extracted.shape == out.shape and np.array_equal(extracted, out):
                    def rule(grid, step_h=step_h, step_w=step_w):
                        arr = safe_array(grid)
                        return arr[::step_h, ::step_w].tolist()
                    
                    return wrap_detector(f"extract_step_{step_h}x{step_w}", rule, 3)
    
    return None


def detect_transpose_rotate(inp, out):
    """Handle transpose + rotation combinations."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Try all 8 combinations: transpose/no-transpose × rotate 0/90/180/270
    operations = [
        (lambda x: x),  # No transpose, no rotate
        (lambda x: np.rot90(x, 1)),  # No transpose, 90°
        (lambda x: np.rot90(x, 2)),  # No transpose, 180°
        (lambda x: np.rot90(x, 3)),  # No transpose, 270°
        (lambda x: np.rot90(x.T, 1)),  # Transpose + 90°
        (lambda x: np.rot90(x.T, 2)),  # Transpose + 180°
        (lambda x: np.rot90(x.T, 3)),  # Transpose + 270°
        (lambda x: x.T),  # Just transpose
    ]
    
    for i, op in enumerate(operations):
        try:
            transformed = op(inp)
            if transformed.shape == out.shape and np.array_equal(transformed, out):
                def rule(grid, op=op):
                    arr = safe_array(grid)
                    return op(arr).tolist()
                
                names = ["none", "rot90", "rot180", "rot270", "trans_rot90", "trans_rot180", "trans_rot270", "transpose"]
                return wrap_detector(f"trans_rot_{names[i]}", rule, 2)
        except:
            continue
    
    return None


def detect_object_count(inp, out):
    """Count and display number of objects - common ARC-2 meta-pattern."""
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None
    
    # Count connected components in input
    from scipy.ndimage import label  # Only if scipy available
    try:
        labeled, num_objects = label(inp != 0)
        if num_objects > 0 and num_objects <= 9:
            # Create a simple number grid
            number_grid = np.zeros_like(inp)
            # Place number in center
            center_r, center_c = inp.shape[0]//2, inp.shape[1]//2
            number_grid[center_r-1:center_r+2, center_c-1:center_c+2] = num_objects
            
            if np.array_equal(number_grid, out):
                def rule(grid):
                    arr = safe_array(grid)
                    try:
                        labeled, num = label(arr != 0)
                        if num > 0 and num <= 9:
                            result = np.zeros_like(arr)
                            cr, cc = arr.shape[0]//2, arr.shape[1]//2
                            result[cr-1:cr+2, cc-1:cc+2] = num
                            return result.tolist()
                    except:
                        pass
                    return arr.tolist()
                
                return wrap_detector(f"object_count_{num_objects}", rule, 4)
    except ImportError:
        pass  # No scipy, skip
    
    return None


def detect_color_histogram(inp, out):
    """Transform based on color frequency patterns."""
    inp, out = safe_array(inp), safe_array(out)
    if inp.shape != out.shape:
        return None
    
    # Create a frequency-based pattern
    unique_colors, counts = np.unique(inp[inp != 0], return_counts=True)
    if len(unique_colors) < 2:
        return None
    
    # Sort colors by frequency
    sorted_idx = np.argsort(counts)[::-1]
    sorted_colors = unique_colors[sorted_idx]
    
    # Fill grid row-by-row with sorted colors
    result = np.zeros_like(inp)
    idx = 0
    for i in range(inp.shape[0]):
        for j in range(inp.shape[1]):
            if idx < len(sorted_colors):
                result[i, j] = sorted_colors[idx]
                idx += 1
            else:
                result[i, j] = sorted_colors[0]  # Repeat most common
    
    if np.array_equal(result, out):
        def rule(grid):
            arr = safe_array(grid)
            unique, counts = np.unique(arr[arr != 0], return_counts=True)
            if len(unique) < 2:
                return arr.tolist()
            
            sorted_idx = np.argsort(counts)[::-1]
            sorted_colors = unique[sorted_idx]
            
            result = np.zeros_like(arr)
            idx = 0
            for i in range(arr.shape[0]):
                for j in range(arr.shape[1]):
                    if idx < len(sorted_colors):
                        result[i, j] = sorted_colors[idx]
                        idx += 1
                    else:
                        result[i, j] = sorted_colors[0]
            return result.tolist()
        
        return wrap_detector("color_histogram", rule, 3)
    
    return None
# --------------------------
# 🔥 SHAPE-CHANGE SPECIALISTS (for 30x30→3x6 type tasks)
# --------------------------

def detect_resize_nearest(inp, out):
    """Resize using nearest-neighbor interpolation."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Check if output dimensions divide input dimensions
    if (inp.shape[0] % out.shape[0] != 0 or inp.shape[1] % out.shape[1] != 0):
        return None
    
    factor_h = inp.shape[0] // out.shape[0]
    factor_w = inp.shape[1] // out.shape[1]
    
    # Nearest neighbor resize
    resized = np.zeros(out.shape, dtype=int)
    for i in range(out.shape[0]):
        for j in range(out.shape[1]):
            resized[i, j] = inp[i*factor_h, j*factor_w]
    
    if np.array_equal(resized, out):
        def rule(grid, factor_h=factor_h, factor_w=factor_w):
            arr = safe_array(grid)
            h, w = arr.shape
            target_h, target_w = h // factor_h, w // factor_w
            if target_h == 0 or target_w == 0:
                return arr.tolist()
            
            result = np.zeros((target_h, target_w), dtype=int)
            for i in range(target_h):
                for j in range(target_w):
                    result[i, j] = arr[i*factor_h, j*factor_w]
            return result.tolist()
        
        return wrap_detector(f"resize_nn_{factor_h}x{factor_w}", rule, 3)

def detect_max_pool(inp, out):
    """Max pooling downsampling."""
    inp, out = safe_array(inp), safe_array(out)
    
    if (inp.shape[0] % out.shape[0] != 0 or inp.shape[1] % out.shape[1] != 0):
        return None
    
    factor_h = inp.shape[0] // out.shape[0]
    factor_w = inp.shape[1] // out.shape[1]
    
    # Max pool
    pooled = np.zeros(out.shape, dtype=int)
    for i in range(out.shape[0]):
        for j in range(out.shape[1]):
            block = inp[i*factor_h:(i+1)*factor_h, j*factor_w:(j+1)*factor_w]
            pooled[i, j] = np.max(block)
    
    if np.array_equal(pooled, out):
        def rule(grid, factor_h=factor_h, factor_w=factor_w):
            arr = safe_array(grid)
            h, w = arr.shape
            target_h, target_w = h // factor_h, w // factor_w
            if target_h == 0 or target_w == 0:
                return arr.tolist()
            
            result = np.zeros((target_h, target_w), dtype=int)
            for i in range(target_h):
                for j in range(target_w):
                    block = arr[i*factor_h:(i+1)*factor_h, j*factor_w:(j+1)*factor_w]
                    result[i, j] = np.max(block)
            return result.tolist()
        
        return wrap_detector(f"max_pool_{factor_h}x{factor_w}", rule, 3)

def detect_spiral_extract(inp, out):
    """Extract spiral pattern from large to small grid."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Simple spiral: take border pixels
    def extract_spiral(grid, target_shape):
        arr = safe_array(grid)
        h, w = arr.shape
        th, tw = target_shape
        
        if th * tw > h * w // 4:  # Too many pixels to extract
            return None
        
        result = np.zeros(target_shape, dtype=int)
        idx = 0
        
        # Simple spiral: outer border clockwise
        # Top row
        for j in range(w):
            if idx < th * tw:
                result[0, idx % tw] = arr[0, j]
                idx += 1
        
        # Right column (skip corner)
        for i in range(1, h-1):
            if idx < th * tw:
                result[(idx // tw) % th, -1] = arr[i, -1]
                idx += 1
        
        # Bottom row (reverse)
        for j in range(w-2, 0, -1):
            if idx < th * tw:
                result[-1, idx % tw] = arr[-1, j]
                idx += 1
        
        # Left column (reverse, skip corner)
        for i in range(h-2, 1, -1):
            if idx < th * tw:
                result[(idx // tw) % th, 0] = arr[i, 0]
                idx += 1
        
        return result
    
    spiral = extract_spiral(inp, out.shape)
    if spiral is not None and np.array_equal(spiral, out):
        def rule(grid):
            arr = safe_array(grid)
            return extract_spiral(arr, out.shape).tolist()
        
        return wrap_detector("spiral_extract", rule, 5)
# --------------------------
# 🔥 COMPRESSION SPECIALISTS (for 30x30→3x6 tasks)
# --------------------------

def detect_block_mean_compress(inp, out):
    """Compress by averaging blocks - common ARC-2 pattern."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Check if dimensions divide evenly
    if (inp.shape[0] % out.shape[0] != 0 or inp.shape[1] % out.shape[1] != 0):
        return None
    
    block_h = inp.shape[0] // out.shape[0]
    block_w = inp.shape[1] // out.shape[1]
    
    if block_h < 1 or block_w < 1:
        return None
    
    # Compute block means
    compressed = np.zeros(out.shape, dtype=int)
    for i in range(out.shape[0]):
        for j in range(out.shape[1]):
            block = inp[i*block_h:(i+1)*block_h, j*block_w:(j+1)*block_w]
            # Use mode (most common value) instead of mean for integers
            flat_block = block.flatten()
            non_zero = flat_block[flat_block != 0]
            if len(non_zero) > 0:
                compressed[i, j] = np.bincount(non_zero).argmax()
            else:
                compressed[i, j] = 0
    
    if np.array_equal(compressed, out):
        def rule(grid, block_h=block_h, block_w=block_w):
            arr = safe_array(grid)
            h, w = arr.shape
            target_h, target_w = h // block_h, w // block_w
            if target_h == 0 or target_w == 0:
                return arr.tolist()
            
            result = np.zeros((target_h, target_w), dtype=int)
            for i in range(target_h):
                for j in range(target_w):
                    block = arr[i*block_h:(i+1)*block_h, j*block_w:(j+1)*block_w]
                    flat_block = block.flatten()
                    non_zero = flat_block[flat_block != 0]
                    if len(non_zero) > 0:
                        result[i, j] = np.bincount(non_zero).argmax()
                    else:
                        result[i, j] = 0
            return result.tolist()
        
        return wrap_detector(f"block_mean_{block_h}x{block_w}", rule, 4)

def detect_row_col_select(inp, out):
    """Select specific rows/columns - common extraction pattern."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Try selecting every Nth row and Mth column
    for row_step in range(1, min(10, inp.shape[0]//out.shape[0] + 1)):
        for col_step in range(1, min(10, inp.shape[1]//out.shape[1] + 1)):
            selected = inp[::row_step, ::col_step]
            if selected.shape == out.shape and np.array_equal(selected, out):
                def rule(grid, row_step=row_step, col_step=col_step):
                    arr = safe_array(grid)
                    return arr[::row_step, ::col_step].tolist()
                
                return wrap_detector(f"rowcol_select_{row_step}x{col_step}", rule, 3)
    
    return None

def detect_border_collapse(inp, out):
    """Collapse borders inward - another ARC-2 favorite."""
    inp, out = safe_array(inp), safe_array(out)
    
    # Check if output is input with borders collapsed
    if out.shape[0] + 2 >= inp.shape[0] and out.shape[1] + 2 >= inp.shape[1]:
        # Try different border widths
        for border in range(1, min(5, (inp.shape[0]-out.shape[0])//2 + 1)):
            collapsed = inp[border:-border or None, border:-border or None]
            if collapsed.shape == out.shape and np.array_equal(collapsed, out):
                def rule(grid, border=border):
                    arr = safe_array(grid)
                    h, w = arr.shape
                    if h <= 2*border or w <= 2*border:
                        return arr.tolist()
                    return arr[border:h-border, border:w-border].tolist()
                
                return wrap_detector(f"border_collapse_{border}", rule, 3)
    
    return None
# --------------------------
# Registry
# --------------------------

DETECTORS = [
    detect_identity,
    detect_flip,
    detect_rotate,
    detect_translation,
    detect_scale,
    detect_mirror_shape,
    detect_recolor,
    detect_symmetry_fill,
    detect_crop,
    detect_pad,
    detect_bounding_box,
    detect_flood_fill,
    detect_fill_gaps,
    detect_diagonal_fill,
    detect_grid_fold,
    detect_fill_pattern,
    detect_align_by_centroid,
    detect_move_object_next_to,
    detect_contained_object_highlight,
    detect_copy_nearby,
    detect_remove_duplicates,
    detect_semantic_fill,
    detect_inside_fill,
    detect_repeat_object,
    detect_stable_fill,
    detect_color_cycle,
    detect_fibonacci_fill,
    detect_arithmetic_repeat,
    detect_core_extension_safe,
    detect_repeat_simple,
    detect_color_swap,
    detect_core_extension,        # Core pattern extension
    detect_connect_components,    # Connect same-color components  
    detect_repeat_with_variation,
    detect_pattern_repeat,        # Tile dominant patterns
    detect_border_extension,      # Extend with borders
    detect_color_gradient,  
    detect_downsample,           # Handles 30x30 → 3x6 compression
    detect_subgrid_extract,      # Extracts representative subgrids
    detect_transpose_rotate,     # All transpose+rotation combos
    detect_object_count,         # Meta: count objects
    detect_color_histogram, 
    detect_resize_nearest,    # Nearest neighbor resize
    detect_max_pool,          # Max pooling downsample  
    detect_spiral_extract, 
    detect_block_mean_compress,   # Block averaging
    detect_row_col_select,        # Row/column selection
    detect_border_collapse,
    *NUMERIC_DETECTORS,  # ✅ correctly unpack list
]


